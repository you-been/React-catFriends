export default [
  {
    id: 1,
    name: "두부",
    age: 3,
    image: "./images/cat1.jpg",
  },
  {
    id: 2,
    name: "찌부",
    age: 6,
    image: "./images/cat2.jpg",
  },
  {
    id: 3,
    name: "요염",
    age: 1,
    image: "./images/cat3.jpg",
  },
  {
    id: 4,
    name: "찌글",
    age: 6,
    image: "./images/cat4.jpg",
  },
  {
    id: 5,
    name: "밤비",
    age: 2,
    image: "./images/cat5.jpg",
  },
];
