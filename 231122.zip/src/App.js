import React from "react";
import "./App.css";
import UseEffect3 from "./components/UseEffect3";
import UseEffect4 from "./components/UseEffect4";
import UseEffect5 from "./components/UseEffect5";
import Ex1useEffect from "./ex/Ex1useEffect";
import Ex2useEffect from "./ex/Ex2useEffect";
import CatFriends from "./components/CatFriends";

function App() {
  return (
    <>
      <h1>리액트</h1>
      {/* <UseEffect3 />
      <UseEffect4 />
      <UseEffect5 />
      <Ex1useEffect />
      <Ex2useEffect />*/}
      <CatFriends />
    </>
  );
}

export default App;
